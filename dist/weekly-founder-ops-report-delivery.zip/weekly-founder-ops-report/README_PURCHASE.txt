Your full pack is at:
https://github.com/aidendify/aidentify-weekly-founder-ops-report

See ACCESS.md
