# Weekly Founder Ops Report Agent — Delivery

Thank you for purchasing from **AIdentify**.

## Your access

**GitHub repository (full product pack):**
https://github.com/aidendify/aidentify-weekly-founder-ops-report

If the repo is public, clone or download ZIP from GitHub.
If we move it private later, reply to your Gumroad receipt and we will add your GitHub username.

```bash
git clone https://github.com/aidendify/aidentify-weekly-founder-ops-report.git
cd aidentify-weekly-founder-ops-report
python3 scripts/validate_pack.py
```

## Quick start
1. Read README.md
2. Read docs/00-overview.md (if present)
3. Import skills into Hermes / Claude / Cursor
4. Customize config.example.yaml
5. Run pack validator / sample path in README

## License
Personal + 1 commercial seat. No resale/redistribution of the pack files.

## Support
Reply on Gumroad to this product.

— AIdentify
